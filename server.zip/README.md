# app_dayTrack_server

# dayTrack

Simple task tracker app.
Main sell is being able to see simple pretty task timelines, printable in future(sell)?